package fundamentals;

public class ArraysMain {

    public static void main(String[] args) {

        int[] ints = {1, 2, 3, 4, 5};

        System.out.println(ints);

        for(int i =0; i< ints.length; i++) {
            System.out.println(ints[i]);
        }

    }

}